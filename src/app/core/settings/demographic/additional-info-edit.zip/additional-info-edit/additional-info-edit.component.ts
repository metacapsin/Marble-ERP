import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-additional-info-edit',
  standalone: true,
  imports: [RouterModule,ReactiveFormsModule,CommonModule],
  templateUrl: './additional-info-edit.component.html',
  styleUrl: './additional-info-edit.component.scss'
})
export class AdditionalInfoEditComponent {
  AdditionalInfoEditGroup: UntypedFormGroup; 
  constructor(private formBuilder: UntypedFormBuilder) {
    this.AdditionalInfoEditGroup = this.formBuilder.group({
      motherFirstName: ['', Validators.required],
      birthOrder: ['', Validators.required],
      multipleBirthMembers: ['', Validators.required],
      citizenship: ['', Validators.required],
      education: ['', Validators.required],
      dateandTimeofDeath: ['', Validators.required],
      pharmacies: ['', Validators.required],
      primaryProvider: ['', Validators.required],
      referredBy: ['', Validators.required],
      referringProvider: ['', Validators.required],
      referralSource: ['', Validators.required],
      notes: ['', Validators.required]
    });
  }
  formData:any = [
    {
      motherFirstName: "Self",
      dateofBirth: "26093 DUMONT RD",
      multipleBirthMembers: "test",
      citizenship: "test",
      education: "test",
      dateandTimeofDeath: "test",
      primaryProvider: "test",
      referredBy: "test",
      referringProvider: "test",
      referralSource: "test",
      notes: "test",
      pharmacies:"test"
    }
  ];


  ngOnInit() {    
    this.patchForm();
  }
  patchForm() {
    this.AdditionalInfoEditGroup.patchValue({
      motherFirstName: this.formData[0].motherFirstName,
      birthOrder: this.formData[0].dateofBirth,
      multipleBirthMembers: this.formData[0].multipleBirthMembers,
      citizenship: this.formData[0].citizenship,
      education: this.formData[0].education,
      dateandTimeofDeath: this.formData[0].dateandTimeofDeath,
      pharmacies: this.formData[0].pharmacies,
      primaryProvider: this.formData[0].primaryProvider,
      referredBy: this.formData[0].referredBy,
      referringProvider: this.formData[0].referringProvider,
      referralSource: this.formData[0].referralSource,
      notes: this.formData[0].notes
    });
  }
  AdditionalInfoEdit(){
    console.log("form:_",this.AdditionalInfoEditGroup.value)  
  }
}
